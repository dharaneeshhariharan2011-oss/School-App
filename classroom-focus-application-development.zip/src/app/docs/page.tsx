import Link from "next/link";

export const metadata = { title: "FocusRoom – Architecture & Client Code" };

export default function DocsPage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <Link href="/" className="text-sm text-slate-500 hover:text-slate-900">
        ← Home
      </Link>
      <h1 className="mt-2 text-3xl font-semibold">Architecture & client code</h1>
      <p className="mt-2 text-slate-600">
        FocusRoom is designed so that no privacy-invasive signal can even be <em>collected</em>, let
        alone transmitted. This page documents the full stack and the actual OS-level / browser-level
        code that the student agent runs.
      </p>

      <Section title="1. Tech stack">
        <ul className="list-disc space-y-1 pl-6 text-sm text-slate-700">
          <li>
            <strong>Teacher dashboard & backend:</strong> Next.js 16 (App Router) + React 19 +
            Tailwind 4. Server-side auth via NextAuth / Google / Microsoft Entra OIDC (demo uses a
            signed HMAC cookie).
          </li>
          <li>
            <strong>Database:</strong> PostgreSQL via Drizzle ORM. Schema in{" "}
            <Code>src/db/schema.ts</Code>.
          </li>
          <li>
            <strong>Realtime:</strong> Server-Sent Events (SSE) from a tiny in-process pub/sub hub
            (<Code>src/lib/realtime.ts</Code>). Swap for Socket.io + Redis Pub/Sub for
            multi-process scale.
          </li>
          <li>
            <strong>Student client:</strong> ship as either a <em>Chrome Extension (MV3)</em> for
            school Chromebooks or an <em>Electron tray app</em> for Windows / macOS. Both use the
            same <Code>/api/student/[token]</Code> endpoints.
          </li>
        </ul>
      </Section>

      <Section title="2. Database schema (Drizzle)">
        <Pre>{`// src/db/schema.ts – summary
teachers   (id, email, name)
sessions   (id, teacher_id, name, code, mode, status,
            blocked_apps[], blocked_domains[],
            allowed_apps[], allowed_domains[],
            auto_unlock_at, created_at, ended_at)
students   (id, session_id, display_name, token, status,
            current_app, current_domain, last_seen, joined_at)
events     (id, session_id, student_id, type, detail, created_at)`}</Pre>
        <p className="mt-2 text-sm text-slate-600">
          Only process names + domain hosts are ever stored. No full URLs, titles, or file paths.
        </p>
      </Section>

      <Section title="3. Realtime (WebSocket / SSE) protocol">
        <p className="text-sm text-slate-600">
          Two channels per session. The teacher dashboard subscribes to the first; every student
          agent subscribes to its own.
        </p>
        <Pre>{`GET /api/sessions/:id/stream        (teacher, SSE)
  event: student.joined   { ...student }
  event: student.status   { id, status, currentApp, currentDomain, lastSeen }
  event: session.update   { ...session }

GET /api/student/:token/stream     (student agent, SSE)
  event: session.update   { ...session }   // mode / ruleset / ended

POST /api/student/:token/heartbeat
  body:    { app?: string, domain?: string }
  reply:   { verdict: { allowed: boolean, reason?: string }, mode }`}</Pre>
        <p className="mt-2 text-sm text-slate-600">
          The server verdict is the same pure function (<Code>evaluate()</Code> in{" "}
          <Code>src/lib/rules.ts</Code>) that the client runs locally for &lt;1ms blocking.
        </p>
      </Section>

      <Section title="4. Chrome Extension (MV3) — safe foreground monitoring">
        <p className="text-sm text-slate-600">
          For Chromebooks and Chrome on any OS. Uses <Code>chrome.tabs</Code> and{" "}
          <Code>chrome.windows</Code> only — no <Code>webRequest</Code> body access, no{" "}
          <Code>&quot;activeTab&quot;</Code> permission for page content.
        </p>
        <Pre>{`// manifest.json
{
  "manifest_version": 3,
  "name": "FocusRoom Student",
  "version": "1.0.0",
  "permissions": ["tabs", "storage", "alarms", "notifications"],
  "host_permissions": [],              // we never read page content
  "background": { "service_worker": "sw.js" },
  "action": { "default_popup": "popup.html" }
}`}</Pre>
        <Pre>{`// sw.js – service worker
const API = "https://focusroom.example/api";
let token = null;
let session = null;

chrome.storage.local.get(["token"], (v) => { token = v.token; connect(); });

function connect() {
  if (!token) return;
  const es = new EventSource(API + "/student/" + token + "/stream");
  es.addEventListener("session.update", (e) => {
    session = JSON.parse(e.data);
    report();
  });
}

async function report() {
  if (!token) return;
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  // ONLY the host is extracted – never the full URL, title, or page content.
  const domain = tab?.url ? new URL(tab.url).hostname : null;
  const res = await fetch(API + "/student/" + token + "/heartbeat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ app: "chrome", domain })
  });
  const { verdict } = await res.json();
  if (!verdict.allowed && tab?.id) {
    // Redirect the offending tab to a friendly intervention page.
    chrome.tabs.update(tab.id, {
      url: chrome.runtime.getURL("blocked.html") +
           "?reason=" + encodeURIComponent(verdict.reason || "")
    });
  }
}

chrome.tabs.onActivated.addListener(report);
chrome.tabs.onUpdated.addListener((_id, info) => { if (info.url) report(); });
chrome.windows.onFocusChanged.addListener(report);
chrome.alarms.create("heartbeat", { periodInMinutes: 0.25 });
chrome.alarms.onAlarm.addListener(report);`}</Pre>
        <p className="mt-2 text-sm text-slate-600">
          Note that the manifest requests <strong>no</strong> host permissions. The extension can
          see which tab is active and its hostname, but cannot read the DOM, cookies, forms, or
          keystrokes.
        </p>
      </Section>

      <Section title="5. Electron agent — safe process monitoring">
        <p className="text-sm text-slate-600">
          For Windows/macOS lab machines. Uses the audited <Code>get-windows</Code> npm package
          which returns the process executable name of the foreground window. We deliberately
          discard the window title before sending.
        </p>
        <Pre>{`// agent/main.js (Electron main process)
import { app, Tray, Menu, nativeImage, BrowserWindow } from "electron";
import { activeWindow } from "get-windows";
import EventSource from "eventsource";

const API = "https://focusroom.example/api";
let token = loadToken();           // stored after /join
let session = null;
let blockWin = null;

app.whenReady().then(async () => {
  new Tray(nativeImage.createEmpty()).setContextMenu(
    Menu.buildFromTemplate([{ label: "FocusRoom (active)", enabled: false }])
  );
  connectRealtime();
  setInterval(tick, 1000);
});

function connectRealtime() {
  const es = new EventSource(\`\${API}/student/\${token}/stream\`);
  es.addEventListener("session.update", (e) => (session = JSON.parse(e.data)));
}

async function tick() {
  const win = await activeWindow();         // { owner: { name, path }, ... }
  if (!win) return;
  // PRIVACY: deliberately drop win.title and win.url – we only forward the
  // process executable name. For browsers we could parse url.hostname only.
  const app = win.owner.name;               // e.g. "Discord.exe"
  const res = await fetch(\`\${API}/student/\${token}/heartbeat\`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ app, domain: null }),
  });
  const { verdict } = await res.json();
  if (!verdict.allowed) showIntervention(verdict.reason);
  else hideIntervention();
}

function showIntervention(reason) {
  if (blockWin) return;
  blockWin = new BrowserWindow({
    fullscreen: true, alwaysOnTop: true, kiosk: true, frame: false,
    skipTaskbar: true, focusable: true,
  });
  blockWin.loadFile("blocked.html", { query: { reason } });
}

function hideIntervention() {
  blockWin?.destroy();
  blockWin = null;
}`}</Pre>
      </Section>

      <Section title="6. The pure verdict function (shared client + server)">
        <Pre>{`// src/lib/rules.ts
export function evaluate(session, { app, domain }) {
  if (session.status !== "active") return { allowed: true };
  if (session.autoUnlockAt && new Date(session.autoUnlockAt) < new Date())
    return { allowed: true };
  if (session.mode === "open") return { allowed: true };
  if (session.mode === "quiz") {
    const ok =
      (app    && session.allowedApps.some(e => app.toLowerCase().includes(e.toLowerCase()))) ||
      (domain && session.allowedDomains.some(e => domain.toLowerCase().includes(e.toLowerCase())));
    return ok ? { allowed: true }
              : { allowed: false, reason: "Only the testing app is permitted." };
  }
  // custom (blacklist)
  if (app    && session.blockedApps.some(e => app.includes(e)))     return { allowed: false, reason: app };
  if (domain && session.blockedDomains.some(e => domain.includes(e))) return { allowed: false, reason: domain };
  return { allowed: true };
}`}</Pre>
      </Section>

      <Section title="7. Privacy guarantees baked into the protocol">
        <ul className="list-disc space-y-1 pl-6 text-sm text-slate-700">
          <li>
            The heartbeat endpoint only accepts <Code>{"{app, domain}"}</Code>. Any extra fields are
            dropped server-side.
          </li>
          <li>Window titles, URL paths, query strings, and file paths are discarded before send.</li>
          <li>No API or extension permission grants access to keystrokes or DOM.</li>
          <li>
            Teachers see <em>status</em> (allowed / blocked) and <em>which process name</em> was
            attempted — never pixels or page content.
          </li>
          <li>
            When the session ends, the server stops returning <Code>allowed:false</Code> verdicts
            and pushes a <Code>session.update</Code> with status=&quot;ended&quot;, which causes the
            agent to tear down any kiosk window.
          </li>
          <li>
            A hard <Code>auto_unlock_at</Code> timestamp acts as a dead-man&apos;s switch — even if
            the teacher&apos;s laptop crashes, the client lifts restrictions.
          </li>
        </ul>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-10">
      <h2 className="text-xl font-semibold">{title}</h2>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-slate-100 px-1 py-0.5 text-[0.85em]">{children}</code>;
}

function Pre({ children }: { children: string }) {
  return (
    <pre className="mt-2 overflow-x-auto rounded-lg bg-slate-900 p-4 text-xs leading-relaxed text-slate-100">
      <code>{children}</code>
    </pre>
  );
}
