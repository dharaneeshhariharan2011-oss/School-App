"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Session, Student } from "@/db/schema";
import { evaluate, type Verdict } from "@/lib/rules";

type SessionView = Session & { teacherName: string };

/**
 * Simulated student agent.
 *
 * On a real device this would be:
 *  - A Chrome Extension that reads chrome.tabs.onActivated + chrome.windows.onFocusChanged
 *  - OR an Electron tray app using active-win / get-windows to read the foreground process name
 *
 * In both cases, the ONLY data sent across the wire is {app, domain}.
 * The verdict is also computed locally (same `evaluate()` function) so blocking
 * is instant and keeps working if the network drops. See /docs for real code.
 */

const SIMULATED_APPS: { label: string; app?: string; domain?: string; icon: string }[] = [
  { label: "Khan Academy", app: "chrome.exe", domain: "khanacademy.org", icon: "📘" },
  { label: "Google Classroom", app: "chrome.exe", domain: "classroom.google.com", icon: "🎓" },
  { label: "Quiz portal", app: "chrome.exe", domain: "quizportal.school.edu", icon: "📝" },
  { label: "YouTube", app: "chrome.exe", domain: "youtube.com", icon: "📺" },
  { label: "Reddit", app: "chrome.exe", domain: "reddit.com", icon: "👽" },
  { label: "TikTok", app: "chrome.exe", domain: "tiktok.com", icon: "🎵" },
  { label: "Discord", app: "Discord.exe", icon: "💬" },
  { label: "Steam", app: "Steam.exe", icon: "🎮" },
  { label: "Minecraft", app: "javaw.exe", icon: "⛏️" },
];

export default function StudentClient({
  token,
  student,
  initialSession,
}: {
  token: string;
  student: Student;
  initialSession: SessionView;
}) {
  const [session, setSession] = useState<SessionView>(initialSession);
  const [active, setActive] = useState<{ app?: string; domain?: string; label: string }>({
    app: "chrome.exe",
    domain: "classroom.google.com",
    label: "Google Classroom",
  });
  const [verdict, setVerdict] = useState<Verdict>({ allowed: true });
  const [connected, setConnected] = useState(false);
  const sentRef = useRef<string>("");

  // Push heartbeat whenever the active "foreground" changes (debounced via sentRef).
  const heartbeat = useCallback(
    async (payload: { app?: string; domain?: string }) => {
      const key = `${payload.app ?? ""}|${payload.domain ?? ""}`;
      if (sentRef.current === key) return;
      sentRef.current = key;
      try {
        const res = await fetch(`/api/student/${token}/heartbeat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const b = (await res.json()) as { verdict: Verdict };
          setVerdict(b.verdict);
        }
      } catch {
        // offline – client-side verdict already applied
      }
    },
    [token],
  );

  // Local evaluation is instantaneous. Server call is just for audit + grid.
  useEffect(() => {
    const local = evaluate(session, active);
    setVerdict(local);
    heartbeat(active);
  }, [session, active, heartbeat]);

  // Periodic heartbeat so the dashboard knows we're still here.
  useEffect(() => {
    const i = setInterval(() => {
      sentRef.current = ""; // force a re-send
      heartbeat(active);
    }, 15_000);
    return () => clearInterval(i);
  }, [active, heartbeat]);

  // Live session updates (mode / ruleset / end) via SSE.
  useEffect(() => {
    const es = new EventSource(`/api/student/${token}/stream`);
    es.onopen = () => setConnected(true);
    es.onerror = () => setConnected(false);
    es.addEventListener("session.update", (e) => {
      const next = JSON.parse((e as MessageEvent).data) as Session;
      setSession((s) => ({ ...s, ...next }));
    });
    return () => es.close();
  }, [token]);

  const sessionActive = session.status === "active";
  const modeLabel =
    session.mode === "open" ? "Open" : session.mode === "quiz" ? "Quiz Mode" : "Custom Focus";

  const borderColor =
    !sessionActive
      ? "border-slate-300"
      : verdict.allowed
        ? session.mode === "open"
          ? "border-slate-300"
          : "border-emerald-500"
        : "border-rose-500";

  return (
    <div className={`min-h-[80vh] ${sessionActive && session.mode !== "open" ? "border-8" : ""} ${borderColor}`}>
      <div className="mx-auto max-w-4xl px-6 py-8">
        <div
          className={`rounded-xl border p-4 ${
            sessionActive
              ? session.mode === "open"
                ? "border-slate-200 bg-white"
                : "border-emerald-200 bg-emerald-50"
              : "border-slate-200 bg-slate-50"
          }`}
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-wide text-slate-500">
                FocusRoom agent · {connected ? "online" : "reconnecting…"}
              </p>
              <h1 className="text-xl font-semibold">
                {sessionActive ? (
                  <>
                    <span className="mr-2">🔒</span>Classroom Focus Mode is{" "}
                    <span className="text-emerald-700">active</span>
                  </>
                ) : (
                  <>
                    <span className="mr-2">🔓</span>Session ended — full control returned
                  </>
                )}
              </h1>
              <p className="mt-1 text-sm text-slate-600">
                Started by <strong>{session.teacherName}</strong> for{" "}
                <strong>{session.name}</strong> · mode: <strong>{modeLabel}</strong>
              </p>
            </div>
            <div className="shrink-0 text-right text-xs text-slate-500">
              <p>Signed in as</p>
              <p className="text-sm font-medium text-slate-900">{student.displayName}</p>
            </div>
          </div>
        </div>

        <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-sm font-medium">Simulate switching apps / tabs</p>
          <p className="text-xs text-slate-500">
            Real agent uses OS APIs. Here, click to simulate a foreground change — see the
            intervention screen appear instantly for blocked targets.
          </p>
          <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-5">
            {SIMULATED_APPS.map((a) => (
              <button
                key={a.label}
                onClick={() => setActive({ app: a.app, domain: a.domain, label: a.label })}
                className={`flex flex-col items-center rounded-lg border p-3 text-xs ${
                  active.label === a.label
                    ? "border-slate-900 bg-slate-900 text-white"
                    : "border-slate-200 bg-white hover:bg-slate-50"
                }`}
              >
                <span className="text-2xl">{a.icon}</span>
                <span className="mt-1 truncate">{a.label}</span>
              </button>
            ))}
          </div>
          <p className="mt-4 text-xs text-slate-500">
            Currently reporting:{" "}
            <code className="rounded bg-slate-100 px-1">
              app={active.app ?? "—"} domain={active.domain ?? "—"}
            </code>
          </p>
        </div>

        <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5 text-sm">
          <p className="font-medium">Your privacy on this device</p>
          <ul className="mt-2 space-y-1 text-slate-600">
            <li>• The agent transmits only the <strong>process name</strong> and <strong>tab host</strong>.</li>
            <li>• No keystrokes, screens, URLs, or files are read.</li>
            <li>• All restrictions are removed the moment the session ends ({sessionActive ? "still active" : "already lifted"}).</li>
          </ul>
        </div>
      </div>

      {sessionActive && !verdict.allowed && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-rose-900/95 p-6 text-white">
          <div className="max-w-lg text-center">
            <div className="text-6xl">🛑</div>
            <h2 className="mt-4 text-2xl font-semibold">Not allowed right now</h2>
            <p className="mt-2 text-rose-100">{verdict.reason}</p>
            <p className="mt-6 text-sm text-rose-200">
              This restriction was set by <strong>{session.teacherName}</strong> for{" "}
              <strong>{session.name}</strong>. It will lift automatically when the session ends.
            </p>
            <button
              onClick={() =>
                setActive({
                  app: "chrome.exe",
                  domain:
                    (session.allowedDomains as string[])[0] ?? "classroom.google.com",
                  label: "Return to class",
                })
              }
              className="mt-6 rounded-md bg-white px-5 py-2 text-sm font-medium text-rose-900 hover:bg-rose-50"
            >
              Return to class
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
