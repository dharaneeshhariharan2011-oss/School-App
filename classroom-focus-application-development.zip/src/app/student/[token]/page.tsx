import { db } from "@/db";
import { students, sessions, teachers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import StudentClient from "./StudentClient";

export const dynamic = "force-dynamic";

export default async function StudentPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const stu = await db.select().from(students).where(eq(students.token, token)).limit(1);
  const student = stu[0];
  if (!student) notFound();

  const sess = await db
    .select()
    .from(sessions)
    .where(eq(sessions.id, student.sessionId))
    .limit(1);
  const session = sess[0];
  if (!session) notFound();

  const teacherRow = await db
    .select({ name: teachers.name })
    .from(teachers)
    .where(eq(teachers.id, session.teacherId))
    .limit(1);

  return (
    <StudentClient
      token={token}
      student={student}
      initialSession={{ ...session, teacherName: teacherRow[0]?.name ?? "Teacher" }}
    />
  );
}
