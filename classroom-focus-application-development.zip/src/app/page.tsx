import Link from "next/link";

export default function Home() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <section className="grid gap-10 md:grid-cols-2 md:items-center">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-emerald-100 px-3 py-1 text-xs font-medium text-emerald-800">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            Privacy-first by design
          </span>
          <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-5xl">
            Keep students focused —
            <br />
            without watching them.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-slate-600">
            FocusRoom lets teachers temporarily block distracting apps and sites during class or a quiz.
            It never records keystrokes, never mirrors the screen, and never scans files. Only process
            and domain names are compared against a teacher-defined allow/block list.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link
              href="/teacher"
              className="rounded-md bg-slate-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-slate-800"
            >
              Open teacher dashboard
            </Link>
            <Link
              href="/join"
              className="rounded-md border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-800 hover:bg-slate-50"
            >
              I&apos;m a student → join
            </Link>
            <Link
              href="/docs"
              className="rounded-md px-5 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-900"
            >
              Architecture & client code →
            </Link>
          </div>
        </div>
        <div className="relative">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between text-xs text-slate-500">
              <span>Mr. Smith · Period 3 Biology</span>
              <span className="rounded bg-amber-100 px-2 py-0.5 font-medium text-amber-800">
                QUIZ MODE
              </span>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {Array.from({ length: 25 }).map((_, i) => {
                const red = [3, 11, 17].includes(i);
                return (
                  <div
                    key={i}
                    className={`flex h-14 flex-col items-center justify-center rounded border text-[10px] ${
                      red
                        ? "border-rose-300 bg-rose-50 text-rose-700"
                        : "border-emerald-200 bg-emerald-50 text-emerald-700"
                    }`}
                  >
                    <span className="font-medium">S{i + 1}</span>
                    <span>{red ? "blocked" : "allowed"}</span>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 text-xs text-slate-500">
              The dashboard shows a traffic-light grid. No screenshots, no window titles — just
              &quot;in an allowed app&quot; vs &quot;tried a blocked app.&quot;
            </p>
          </div>
        </div>
      </section>

      <section className="mt-20 grid gap-6 md:grid-cols-3">
        {[
          {
            title: "What we DO monitor",
            tone: "bg-emerald-50 border-emerald-200 text-emerald-900",
            items: [
              "Name of the active foreground application",
              "Domain of the active browser tab",
              "Timestamps of mode changes",
            ],
          },
          {
            title: "What we NEVER touch",
            tone: "bg-rose-50 border-rose-200 text-rose-900",
            items: [
              "Keystrokes or passwords",
              "Screen pixels or screenshots",
              "File system contents or grades",
              "Full URLs, query strings, DMs",
            ],
          },
          {
            title: "Student controls",
            tone: "bg-sky-50 border-sky-200 text-sky-900",
            items: [
              "Visible banner naming the teacher",
              "Auto-unlock when session ends",
              "Hard timer with auto-expire",
              "Pseudonymous join via code",
            ],
          },
        ].map((card) => (
          <div key={card.title} className={`rounded-xl border p-5 ${card.tone}`}>
            <h3 className="font-semibold">{card.title}</h3>
            <ul className="mt-3 space-y-2 text-sm">
              {card.items.map((i) => (
                <li key={i} className="flex gap-2">
                  <span>•</span>
                  <span>{i}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </section>
    </div>
  );
}
