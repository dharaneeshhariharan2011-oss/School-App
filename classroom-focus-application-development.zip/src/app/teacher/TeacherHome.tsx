"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { Session, Teacher } from "@/db/schema";

export default function TeacherHome({
  teacher,
  initialSessions,
}: {
  teacher: Teacher;
  initialSessions: Session[];
}) {
  const [sessions, setSessions] = useState<Session[]>(initialSessions);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function createSession() {
    setLoading(true);
    const res = await fetch("/api/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name || "Class Session" }),
    });
    setLoading(false);
    if (res.ok) {
      const { session } = await res.json();
      setSessions([session, ...sessions]);
      setName("");
      router.push(`/teacher/sessions/${session.id}`);
    }
  }

  async function logout() {
    await fetch("/api/teacher/logout", { method: "POST" });
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-500">Signed in as</p>
          <h1 className="text-2xl font-semibold">{teacher.name}</h1>
        </div>
        <button
          onClick={logout}
          className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm hover:bg-slate-50"
        >
          Sign out
        </button>
      </div>

      <div className="mt-8 rounded-xl border border-slate-200 bg-white p-5">
        <h2 className="font-semibold">Start a new class session</h2>
        <p className="text-sm text-slate-600">
          A short join code will be generated. Share it with your class.
        </p>
        <div className="mt-3 flex gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Period 3 – Chapter 7 Quiz"
            className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-slate-500"
          />
          <button
            onClick={createSession}
            disabled={loading}
            className="rounded-md bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            {loading ? "Creating…" : "Create session"}
          </button>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="mb-3 font-semibold">Your sessions</h2>
        {sessions.length === 0 ? (
          <p className="text-sm text-slate-500">No sessions yet. Create one above.</p>
        ) : (
          <ul className="space-y-2">
            {sessions.map((s) => (
              <li key={s.id}>
                <Link
                  href={`/teacher/sessions/${s.id}`}
                  className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-4 py-3 hover:border-slate-400"
                >
                  <div>
                    <p className="font-medium">{s.name}</p>
                    <p className="text-xs text-slate-500">
                      Code <span className="font-mono text-slate-800">{s.code}</span> ·{" "}
                      {s.status === "active" ? "Active" : "Ended"} · mode {s.mode}
                    </p>
                  </div>
                  <span className="text-sm text-slate-400">Open →</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
