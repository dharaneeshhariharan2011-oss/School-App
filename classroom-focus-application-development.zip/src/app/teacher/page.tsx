import { getCurrentTeacher } from "@/lib/auth";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import TeacherHome from "./TeacherHome";
import LoginForm from "./LoginForm";

export const dynamic = "force-dynamic";

export default async function TeacherPage() {
  const teacher = await getCurrentTeacher();
  if (!teacher) {
    return (
      <div className="mx-auto max-w-md px-6 py-16">
        <h1 className="text-2xl font-semibold">Teacher sign-in</h1>
        <p className="mt-2 text-sm text-slate-600">
          In production this screen would redirect to Google / Microsoft SSO. For the demo, enter
          your school email to continue.
        </p>
        <div className="mt-6">
          <LoginForm />
        </div>
      </div>
    );
  }

  const list = await db
    .select()
    .from(sessions)
    .where(eq(sessions.teacherId, teacher.id))
    .orderBy(desc(sessions.createdAt));

  return <TeacherHome teacher={teacher} initialSessions={list} />;
}


