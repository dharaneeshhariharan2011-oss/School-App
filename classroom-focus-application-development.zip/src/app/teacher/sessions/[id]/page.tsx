import { getCurrentTeacher } from "@/lib/auth";
import { db } from "@/db";
import { sessions, students, events } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { notFound, redirect } from "next/navigation";
import SessionConsole from "./SessionConsole";

export const dynamic = "force-dynamic";

export default async function SessionDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const teacher = await getCurrentTeacher();
  if (!teacher) redirect("/teacher");

  const { id } = await params;
  const sessionId = Number(id);
  if (!Number.isFinite(sessionId)) notFound();

  const rows = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.id, sessionId), eq(sessions.teacherId, teacher.id)))
    .limit(1);
  const session = rows[0];
  if (!session) notFound();

  const roster = await db.select().from(students).where(eq(students.sessionId, sessionId));
  const recent = await db
    .select()
    .from(events)
    .where(eq(events.sessionId, sessionId))
    .orderBy(desc(events.createdAt))
    .limit(50);

  return (
    <SessionConsole initialSession={session} initialStudents={roster} initialEvents={recent} />
  );
}
