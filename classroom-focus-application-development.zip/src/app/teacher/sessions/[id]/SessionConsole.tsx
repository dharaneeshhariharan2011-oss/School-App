"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { Session, Student, Event } from "@/db/schema";

type Mode = "open" | "quiz" | "custom";

export default function SessionConsole({
  initialSession,
  initialStudents,
  initialEvents,
}: {
  initialSession: Session;
  initialStudents: Student[];
  initialEvents: Event[];
}) {
  const [session, setSession] = useState<Session>(initialSession);
  const [roster, setRoster] = useState<Student[]>(initialStudents);
  const [log, setLog] = useState<Event[]>(initialEvents);
  const router = useRouter();

  const joinUrl = useMemo(() => {
    if (typeof window === "undefined") return "";
    return `${window.location.origin}/join?code=${session.code}`;
  }, [session.code]);

  // Subscribe to the per-session SSE channel for live updates.
  useEffect(() => {
    const es = new EventSource(`/api/sessions/${session.id}/stream`);
    es.addEventListener("student.joined", (e) => {
      const student = JSON.parse((e as MessageEvent).data) as Student;
      setRoster((r) => (r.some((x) => x.id === student.id) ? r : [...r, student]));
      setLog((l) => [
        {
          id: Math.random(),
          sessionId: session.id,
          studentId: student.id,
          type: "student.joined",
          detail: `${student.displayName} joined`,
          createdAt: new Date(),
        } as Event,
        ...l,
      ]);
    });
    es.addEventListener("student.status", (e) => {
      const upd = JSON.parse((e as MessageEvent).data) as {
        id: number;
        status: string;
        currentApp: string | null;
        currentDomain: string | null;
        lastSeen: string;
      };
      setRoster((r) =>
        r.map((s) =>
          s.id === upd.id
            ? {
                ...s,
                status: upd.status,
                currentApp: upd.currentApp,
                currentDomain: upd.currentDomain,
                lastSeen: new Date(upd.lastSeen),
              }
            : s,
        ),
      );
    });
    es.addEventListener("session.update", (e) => {
      const next = JSON.parse((e as MessageEvent).data) as Session;
      setSession(next);
    });
    return () => es.close();
  }, [session.id]);

  async function patch(body: Record<string, unknown>) {
    const res = await fetch(`/api/sessions/${session.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (res.ok) {
      const { session: next } = await res.json();
      setSession(next);
    }
  }

  async function endSession() {
    if (!confirm("End the session and lift all restrictions?")) return;
    await patch({ status: "ended" });
    router.refresh();
  }

  const connected = roster.filter((s) => s.status !== "offline").length;
  const blocked = roster.filter((s) => s.status === "blocked").length;

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <Link href="/teacher" className="text-sm text-slate-500 hover:text-slate-900">
            ← All sessions
          </Link>
          <h1 className="mt-1 text-2xl font-semibold">{session.name}</h1>
          <p className="mt-1 text-sm text-slate-600">
            Join code <span className="rounded bg-slate-100 px-2 py-0.5 font-mono text-slate-900">{session.code}</span>
            {" · "}
            <ModeBadge mode={session.mode as Mode} />
            {session.status !== "active" && (
              <span className="ml-2 rounded bg-slate-200 px-2 py-0.5 text-xs">ENDED</span>
            )}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Share: <span className="font-mono">{joinUrl}</span>
          </p>
        </div>
        <div className="flex gap-2">
          {session.status === "active" && (
            <button
              onClick={endSession}
              className="rounded-md border border-rose-300 bg-white px-3 py-1.5 text-sm font-medium text-rose-700 hover:bg-rose-50"
            >
              End session & unlock
            </button>
          )}
        </div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <Stat label="Connected" value={connected} />
        <Stat label="In allowed app" value={connected - blocked} tone="emerald" />
        <Stat label="Blocked attempts (now)" value={blocked} tone="rose" />
      </div>

      {session.status === "active" && (
        <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="font-semibold">Focus mode</h2>
          <p className="text-sm text-slate-600">
            Toggle instantly. All connected students receive the new rules in &lt; 1s via the
            realtime channel.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {(["open", "quiz", "custom"] as const).map((m) => (
              <button
                key={m}
                onClick={() => patch({ mode: m })}
                className={`rounded-md px-4 py-2 text-sm font-medium ${
                  session.mode === m
                    ? "bg-slate-900 text-white"
                    : "border border-slate-300 bg-white hover:bg-slate-50"
                }`}
              >
                {m.toUpperCase()}
              </button>
            ))}
          </div>
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <RuleList
              title="Allowed apps (quiz mode whitelist)"
              hint="process names, e.g. chrome.exe"
              values={session.allowedApps as string[]}
              onChange={(allowedApps) => patch({ allowedApps })}
            />
            <RuleList
              title="Allowed domains (quiz mode whitelist)"
              hint="hosts, e.g. khanacademy.org"
              values={session.allowedDomains as string[]}
              onChange={(allowedDomains) => patch({ allowedDomains })}
            />
            <RuleList
              title="Blocked apps (custom-mode blacklist)"
              hint="process names, e.g. Discord.exe"
              values={session.blockedApps as string[]}
              onChange={(blockedApps) => patch({ blockedApps })}
            />
            <RuleList
              title="Blocked domains (custom-mode blacklist)"
              hint="hosts, e.g. tiktok.com"
              values={session.blockedDomains as string[]}
              onChange={(blockedDomains) => patch({ blockedDomains })}
            />
          </div>
        </div>
      )}

      <div className="mt-6">
        <h2 className="mb-3 font-semibold">Student status grid</h2>
        {roster.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">
            No students have joined yet. Share the code{" "}
            <span className="font-mono font-semibold">{session.code}</span>.
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
            {roster.map((s) => {
              const tone =
                s.status === "blocked"
                  ? "border-rose-300 bg-rose-50 text-rose-800"
                  : s.status === "allowed"
                    ? "border-emerald-300 bg-emerald-50 text-emerald-800"
                    : "border-slate-200 bg-slate-50 text-slate-500";
              return (
                <div key={s.id} className={`rounded-lg border p-3 ${tone}`}>
                  <div className="flex items-center justify-between">
                    <p className="truncate font-medium">{s.displayName}</p>
                    <span
                      className={`h-2 w-2 rounded-full ${
                        s.status === "blocked"
                          ? "bg-rose-500"
                          : s.status === "allowed"
                            ? "bg-emerald-500"
                            : "bg-slate-400"
                      }`}
                    />
                  </div>
                  <p className="mt-1 truncate text-[11px] opacity-80">
                    {s.status === "blocked"
                      ? `tried ${s.currentApp || s.currentDomain || "a blocked app"}`
                      : s.status === "allowed"
                        ? "in an allowed app"
                        : "offline"}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-8">
        <h2 className="mb-3 font-semibold">Recent events (privacy-safe audit log)</h2>
        <div className="rounded-xl border border-slate-200 bg-white">
          {log.length === 0 ? (
            <p className="p-4 text-sm text-slate-500">No events yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {log.slice(0, 25).map((e) => (
                <li key={String(e.id)} className="flex items-start gap-3 px-4 py-2">
                  <span
                    className={`mt-1 inline-block h-2 w-2 shrink-0 rounded-full ${
                      e.type === "student.blocked"
                        ? "bg-rose-500"
                        : e.type === "student.allowed"
                          ? "bg-emerald-500"
                          : "bg-slate-400"
                    }`}
                  />
                  <div className="flex-1">
                    <p>{e.detail || e.type}</p>
                    <p className="text-xs text-slate-400">
                      {new Date(e.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone = "slate",
}: {
  label: string;
  value: number;
  tone?: "slate" | "emerald" | "rose";
}) {
  const toneCls =
    tone === "emerald"
      ? "text-emerald-700"
      : tone === "rose"
        ? "text-rose-700"
        : "text-slate-900";
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5">
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-1 text-3xl font-semibold ${toneCls}`}>{value}</p>
    </div>
  );
}

function ModeBadge({ mode }: { mode: Mode }) {
  const map: Record<Mode, string> = {
    open: "bg-slate-100 text-slate-800",
    quiz: "bg-amber-100 text-amber-800",
    custom: "bg-sky-100 text-sky-800",
  };
  return <span className={`rounded px-2 py-0.5 text-xs font-medium ${map[mode]}`}>{mode.toUpperCase()}</span>;
}

function RuleList({
  title,
  hint,
  values,
  onChange,
}: {
  title: string;
  hint: string;
  values: string[];
  onChange: (next: string[]) => void;
}) {
  const [draft, setDraft] = useState("");
  return (
    <div className="rounded-lg border border-slate-200 p-3">
      <p className="text-sm font-medium">{title}</p>
      <p className="text-xs text-slate-500">{hint}</p>
      <div className="mt-2 flex flex-wrap gap-1">
        {values.map((v) => (
          <span
            key={v}
            className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs"
          >
            {v}
            <button
              onClick={() => onChange(values.filter((x) => x !== v))}
              className="text-slate-400 hover:text-rose-600"
              aria-label={`remove ${v}`}
            >
              ×
            </button>
          </span>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="add…"
          className="flex-1 rounded border border-slate-300 px-2 py-1 text-sm outline-none focus:border-slate-500"
          onKeyDown={(e) => {
            if (e.key === "Enter" && draft.trim()) {
              onChange([...values, draft.trim()]);
              setDraft("");
            }
          }}
        />
        <button
          onClick={() => {
            if (draft.trim()) {
              onChange([...values, draft.trim()]);
              setDraft("");
            }
          }}
          className="rounded bg-slate-900 px-2 py-1 text-xs text-white hover:bg-slate-700"
        >
          Add
        </button>
      </div>
    </div>
  );
}
