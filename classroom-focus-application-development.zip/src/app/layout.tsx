import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "FocusRoom – Classroom Focus & Anti-Cheating",
  description:
    "Privacy-first classroom focus tool. Block distractions without screen monitoring, keystroke logging, or file inspection.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <header className="border-b border-slate-200 bg-white">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <span className="inline-flex h-7 w-7 items-center justify-center rounded-md bg-emerald-500 text-white">
                ◉
              </span>
              <span>FocusRoom</span>
            </Link>
            <nav className="flex items-center gap-4 text-sm text-slate-600">
              <Link className="hover:text-slate-900" href="/teacher">Teacher</Link>
              <Link className="hover:text-slate-900" href="/join">Student join</Link>
              <Link className="hover:text-slate-900" href="/docs">Docs</Link>
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="mt-16 border-t border-slate-200 bg-white">
          <div className="mx-auto max-w-6xl px-6 py-6 text-xs text-slate-500">
            FocusRoom is a privacy-first demo. No keystrokes, no screens, no files – just process &
            domain names.
          </div>
        </footer>
      </body>
    </html>
  );
}
