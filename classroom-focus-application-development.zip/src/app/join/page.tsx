import JoinForm from "./JoinForm";

export const dynamic = "force-dynamic";

export default async function JoinPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string }>;
}) {
  const sp = await searchParams;
  return (
    <div className="mx-auto max-w-md px-6 py-16">
      <h1 className="text-2xl font-semibold">Join a class</h1>
      <p className="mt-2 text-sm text-slate-600">
        Enter the code your teacher shared. You can join anonymously – we never ask for personal
        data.
      </p>
      <div className="mt-6">
        <JoinForm initialCode={sp.code ?? ""} />
      </div>
    </div>
  );
}
