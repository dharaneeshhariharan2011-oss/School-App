"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function JoinForm({ initialCode }: { initialCode: string }) {
  const [code, setCode] = useState(initialCode);
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/join", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, displayName }),
    });
    setLoading(false);
    if (!res.ok) {
      const b = await res.json().catch(() => ({ error: "Failed to join" }));
      setError(b.error ?? "Failed to join");
      return;
    }
    const { token } = await res.json();
    router.push(`/student/${token}`);
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl border border-slate-200 bg-white p-5">
      <div>
        <label className="block text-sm font-medium">Session code</label>
        <input
          required
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="ABC123"
          className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-lg font-mono tracking-widest outline-none focus:border-slate-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium">Display name (optional)</label>
        <input
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="e.g. Row 3 Seat 4"
          className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-sm outline-none focus:border-slate-500"
        />
        <p className="mt-1 text-xs text-slate-500">
          If left blank you&apos;ll show up as &quot;Anonymous.&quot; Nothing links this device to a
          real identity.
        </p>
      </div>
      {error && <p className="text-sm text-rose-600">{error}</p>}
      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-md bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50"
      >
        {loading ? "Joining…" : "Join session"}
      </button>
    </form>
  );
}
