import { NextRequest } from "next/server";
import { db } from "@/db";
import { sessions, students, teachers } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const stu = await db.select().from(students).where(eq(students.token, token)).limit(1);
  const student = stu[0];
  if (!student) return Response.json({ error: "not found" }, { status: 404 });

  const sess = await db.select().from(sessions).where(eq(sessions.id, student.sessionId)).limit(1);
  const session = sess[0];
  if (!session) return Response.json({ error: "not found" }, { status: 404 });

  const teacherRow = await db
    .select({ name: teachers.name })
    .from(teachers)
    .where(eq(teachers.id, session.teacherId))
    .limit(1);

  return Response.json({
    student,
    session: { ...session, teacherName: teacherRow[0]?.name ?? "Teacher" },
  });
}
