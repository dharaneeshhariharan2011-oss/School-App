import { NextRequest } from "next/server";
import { db } from "@/db";
import { sessions, students, events } from "@/db/schema";
import { eq } from "drizzle-orm";
import { evaluate } from "@/lib/rules";
import { publishToSession } from "@/lib/realtime";

export const dynamic = "force-dynamic";

/**
 * The student agent calls this every few seconds (and immediately on
 * foreground-change) with the ONLY two pieces of data we ever transmit:
 *   - app:    the executable / process name of the active foreground window
 *   - domain: the host of the active browser tab (if any)
 *
 * No URLs with query strings. No window titles. No file paths.
 * Verdict is evaluated server-side AND trusted client-side (see /lib/rules).
 */
export async function POST(req: NextRequest, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const app = typeof body.app === "string" ? body.app.slice(0, 160) : null;
  const domain =
    typeof body.domain === "string"
      ? body.domain.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "").slice(0, 253)
      : null;

  const stu = await db.select().from(students).where(eq(students.token, token)).limit(1);
  const student = stu[0];
  if (!student) return Response.json({ error: "not found" }, { status: 404 });

  const sess = await db
    .select()
    .from(sessions)
    .where(eq(sessions.id, student.sessionId))
    .limit(1);
  const session = sess[0];
  if (!session) return Response.json({ error: "not found" }, { status: 404 });

  const verdict = evaluate(session, { app, domain });
  const nextStatus = verdict.allowed ? "allowed" : "blocked";
  const previousStatus = student.status;

  await db
    .update(students)
    .set({
      status: nextStatus,
      currentApp: app,
      currentDomain: domain,
      lastSeen: new Date(),
    })
    .where(eq(students.id, student.id));

  // Only emit on changes to keep the event log readable.
  if (previousStatus !== nextStatus) {
    await db.insert(events).values({
      sessionId: session.id,
      studentId: student.id,
      type: verdict.allowed ? "student.allowed" : "student.blocked",
      detail: verdict.allowed
        ? `${student.displayName} returned to an allowed app`
        : `${student.displayName} tried: ${app ?? ""} ${domain ? `(${domain})` : ""}`.trim(),
    });
  }

  publishToSession(session.id, "student.status", {
    id: student.id,
    status: nextStatus,
    currentApp: app,
    currentDomain: domain,
    lastSeen: new Date().toISOString(),
  });

  return Response.json({ verdict, mode: session.mode });
}
