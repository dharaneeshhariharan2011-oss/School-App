import { logoutTeacher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST() {
  await logoutTeacher();
  return Response.json({ ok: true });
}
