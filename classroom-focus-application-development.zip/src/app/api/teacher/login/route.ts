import { NextRequest } from "next/server";
import { loginTeacher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body.email !== "string") {
    return Response.json({ error: "email required" }, { status: 400 });
  }
  try {
    const teacher = await loginTeacher(body.email, body.name ?? "");
    return Response.json({ teacher });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "Login failed" },
      { status: 400 },
    );
  }
}
