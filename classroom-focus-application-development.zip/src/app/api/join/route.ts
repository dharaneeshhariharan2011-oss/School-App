import { NextRequest } from "next/server";
import { db } from "@/db";
import { sessions, students, events, teachers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { publishToSession } from "@/lib/realtime";
import crypto from "node:crypto";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const code = String(body.code ?? "").trim().toUpperCase().slice(0, 10);
  const displayName = String(body.displayName ?? "").trim().slice(0, 80) || "Anonymous";
  if (!code) return Response.json({ error: "code required" }, { status: 400 });

  const sess = await db.select().from(sessions).where(eq(sessions.code, code)).limit(1);
  const session = sess[0];
  if (!session || session.status !== "active") {
    return Response.json({ error: "Session not found or ended." }, { status: 404 });
  }

  const token = crypto.randomBytes(24).toString("base64url");

  const inserted = await db
    .insert(students)
    .values({
      sessionId: session.id,
      displayName,
      token,
      status: "allowed",
      lastSeen: new Date(),
    })
    .returning();
  const student = inserted[0];

  await db.insert(events).values({
    sessionId: session.id,
    studentId: student.id,
    type: "student.joined",
    detail: `${displayName} joined`,
  });

  publishToSession(session.id, "student.joined", student);

  const teacherRow = await db
    .select({ name: teachers.name })
    .from(teachers)
    .where(eq(teachers.id, session.teacherId))
    .limit(1);

  return Response.json({
    token,
    student,
    session: {
      id: session.id,
      name: session.name,
      mode: session.mode,
      status: session.status,
      blockedApps: session.blockedApps,
      blockedDomains: session.blockedDomains,
      allowedApps: session.allowedApps,
      allowedDomains: session.allowedDomains,
      autoUnlockAt: session.autoUnlockAt,
      teacherName: teacherRow[0]?.name ?? "Your teacher",
    },
  });
}
