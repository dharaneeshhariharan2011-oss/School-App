import { NextRequest } from "next/server";
import { db } from "@/db";
import { sessions, students, events } from "@/db/schema";
import { getCurrentTeacher } from "@/lib/auth";
import { and, desc, eq } from "drizzle-orm";
import { publishToSession, publishToStudent } from "@/lib/realtime";

export const dynamic = "force-dynamic";

async function loadSessionForTeacher(id: number, teacherId: number) {
  const rows = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.id, id), eq(sessions.teacherId, teacherId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const teacher = await getCurrentTeacher();
  if (!teacher) return Response.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const sessionId = Number(id);
  const session = await loadSessionForTeacher(sessionId, teacher.id);
  if (!session) return Response.json({ error: "not found" }, { status: 404 });

  const roster = await db
    .select()
    .from(students)
    .where(eq(students.sessionId, sessionId));

  const recent = await db
    .select()
    .from(events)
    .where(eq(events.sessionId, sessionId))
    .orderBy(desc(events.createdAt))
    .limit(50);

  return Response.json({ session, students: roster, events: recent });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const teacher = await getCurrentTeacher();
  if (!teacher) return Response.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const sessionId = Number(id);
  const session = await loadSessionForTeacher(sessionId, teacher.id);
  if (!session) return Response.json({ error: "not found" }, { status: 404 });

  const body = await req.json().catch(() => ({}));

  const patch: Record<string, unknown> = {};
  if (typeof body.name === "string") patch.name = body.name.slice(0, 160);
  if (["open", "quiz", "custom"].includes(body.mode)) patch.mode = body.mode;
  if (Array.isArray(body.blockedApps)) patch.blockedApps = body.blockedApps.map(String);
  if (Array.isArray(body.blockedDomains))
    patch.blockedDomains = body.blockedDomains.map((d: string) =>
      String(d).toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""),
    );
  if (Array.isArray(body.allowedApps)) patch.allowedApps = body.allowedApps.map(String);
  if (Array.isArray(body.allowedDomains))
    patch.allowedDomains = body.allowedDomains.map((d: string) =>
      String(d).toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""),
    );
  if (body.autoUnlockAt === null) patch.autoUnlockAt = null;
  else if (typeof body.autoUnlockAt === "string")
    patch.autoUnlockAt = new Date(body.autoUnlockAt);

  if (body.status === "ended") {
    patch.status = "ended";
    patch.endedAt = new Date();
    patch.mode = "open";
  }

  const updated = await db
    .update(sessions)
    .set(patch)
    .where(eq(sessions.id, sessionId))
    .returning();
  const next = updated[0];

  // Broadcast the new ruleset to every connected student + the teacher.
  publishToSession(sessionId, "session.update", next);
  const roster = await db
    .select()
    .from(students)
    .where(eq(students.sessionId, sessionId));
  for (const s of roster) {
    publishToStudent(s.token, "session.update", next);
  }

  if (patch.status === "ended") {
    await db.insert(events).values({
      sessionId,
      type: "session.ended",
      detail: "Teacher ended the session. All restrictions lifted.",
    });
  } else if (patch.mode) {
    await db.insert(events).values({
      sessionId,
      type: "mode.change",
      detail: `Mode set to ${String(patch.mode).toUpperCase()}`,
    });
  }

  return Response.json({ session: next });
}
