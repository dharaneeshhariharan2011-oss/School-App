import { NextRequest } from "next/server";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { getCurrentTeacher } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";
import crypto from "node:crypto";

export const dynamic = "force-dynamic";

function newCode(): string {
  // 6-char base32-ish code, easy to say out loud.
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let out = "";
  const bytes = crypto.randomBytes(6);
  for (let i = 0; i < 6; i++) out += alphabet[bytes[i] % alphabet.length];
  return out;
}

export async function GET() {
  const teacher = await getCurrentTeacher();
  if (!teacher) return Response.json({ error: "unauthorized" }, { status: 401 });
  const rows = await db
    .select()
    .from(sessions)
    .where(eq(sessions.teacherId, teacher.id))
    .orderBy(desc(sessions.createdAt));
  return Response.json({ sessions: rows });
}

export async function POST(req: NextRequest) {
  const teacher = await getCurrentTeacher();
  if (!teacher) return Response.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const name = String(body.name ?? "Class Session").slice(0, 160);

  const inserted = await db
    .insert(sessions)
    .values({
      teacherId: teacher.id,
      name,
      code: newCode(),
      mode: "open",
      status: "active",
      blockedApps: ["Discord.exe", "Steam.exe"],
      blockedDomains: ["youtube.com", "tiktok.com", "reddit.com"],
      allowedApps: ["chrome.exe", "msedge.exe"],
      allowedDomains: ["classroom.google.com", "khanacademy.org"],
    })
    .returning();

  return Response.json({ session: inserted[0] });
}
