import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  jsonb,
  varchar,
  index,
} from "drizzle-orm/pg-core";

/**
 * Teachers are the only identified humans in the system.
 * They authenticate via SSO (Google / Microsoft) in production; this starter
 * stores just the SSO-derived profile (email, name).
 */
export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/**
 * A classroom session. Students join via `code`.
 * `mode` controls which rule set is active:
 *   open   = nothing is blocked
 *   quiz   = only `allowedDomains` / `allowedApps` are permitted
 *   custom = everything is allowed EXCEPT `blockedDomains` / `blockedApps`
 */
export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    teacherId: integer("teacher_id")
      .notNull()
      .references(() => teachers.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 160 }).notNull(),
    code: varchar("code", { length: 10 }).notNull().unique(),
    mode: varchar("mode", { length: 16 }).notNull().default("open"),
    status: varchar("status", { length: 16 }).notNull().default("active"),
    blockedApps: jsonb("blocked_apps").notNull().default([]),
    blockedDomains: jsonb("blocked_domains").notNull().default([]),
    allowedApps: jsonb("allowed_apps").notNull().default([]),
    allowedDomains: jsonb("allowed_domains").notNull().default([]),
    autoUnlockAt: timestamp("auto_unlock_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    endedAt: timestamp("ended_at"),
  },
  (t) => [index("sessions_code_idx").on(t.code)],
);

/**
 * A student is pseudonymous – a random token acts as their credential.
 * We never store email unless they explicitly type it as a display name.
 */
export const students = pgTable(
  "students",
  {
    id: serial("id").primaryKey(),
    sessionId: integer("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    displayName: varchar("display_name", { length: 80 }).notNull(),
    token: varchar("token", { length: 48 }).notNull().unique(),
    status: varchar("status", { length: 16 }).notNull().default("offline"),
    currentApp: varchar("current_app", { length: 160 }),
    currentDomain: varchar("current_domain", { length: 253 }),
    lastSeen: timestamp("last_seen"),
    joinedAt: timestamp("joined_at").notNull().defaultNow(),
  },
  (t) => [
    index("students_session_idx").on(t.sessionId),
    index("students_token_idx").on(t.token),
  ],
);

/**
 * Append-only audit log. Only process / domain names and verdicts – never
 * screen content, keystrokes, or file paths.
 */
export const events = pgTable(
  "events",
  {
    id: serial("id").primaryKey(),
    sessionId: integer("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    studentId: integer("student_id").references(() => students.id, {
      onDelete: "cascade",
    }),
    type: varchar("type", { length: 32 }).notNull(),
    detail: text("detail"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("events_session_idx").on(t.sessionId)],
);

export type Teacher = typeof teachers.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Student = typeof students.$inferSelect;
export type Event = typeof events.$inferSelect;
