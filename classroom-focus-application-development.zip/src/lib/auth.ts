import { cookies } from "next/headers";
import { db } from "@/db";
import { teachers } from "@/db/schema";
import { eq } from "drizzle-orm";
import crypto from "node:crypto";

const COOKIE_NAME = "cf_teacher";

/**
 * In production this cookie would be a signed JWT issued after a Google /
 * Microsoft OAuth callback. For the starter we store the teacher id directly
 * in an HttpOnly cookie signed with a server-only HMAC secret.
 */
function secret(): string {
  return process.env.AUTH_SECRET || "dev-insecure-secret-change-me";
}

function sign(value: string): string {
  return crypto.createHmac("sha256", secret()).update(value).digest("hex");
}

function pack(id: number): string {
  const payload = String(id);
  return `${payload}.${sign(payload)}`;
}

function unpack(cookie: string | undefined): number | null {
  if (!cookie) return null;
  const [payload, sig] = cookie.split(".");
  if (!payload || !sig) return null;
  if (sign(payload) !== sig) return null;
  const id = Number(payload);
  if (!Number.isFinite(id)) return null;
  return id;
}

export async function loginTeacher(email: string, name: string) {
  const normalized = email.trim().toLowerCase();
  if (!normalized || !normalized.includes("@")) {
    throw new Error("Invalid email");
  }
  const safeName = (name || normalized.split("@")[0]).trim().slice(0, 160);

  const existing = await db
    .select()
    .from(teachers)
    .where(eq(teachers.email, normalized))
    .limit(1);

  let teacher = existing[0];
  if (!teacher) {
    const inserted = await db
      .insert(teachers)
      .values({ email: normalized, name: safeName })
      .returning();
    teacher = inserted[0];
  }

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, pack(teacher.id), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
    secure: process.env.NODE_ENV === "production",
  });

  return teacher;
}

export async function logoutTeacher() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

export async function getCurrentTeacher() {
  const cookieStore = await cookies();
  const raw = cookieStore.get(COOKIE_NAME)?.value;
  const id = unpack(raw);
  if (!id) return null;
  const rows = await db.select().from(teachers).where(eq(teachers.id, id)).limit(1);
  return rows[0] ?? null;
}
