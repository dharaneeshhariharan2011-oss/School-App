import type { Session } from "@/db/schema";

export type FocusMode = "open" | "quiz" | "custom";

export type Verdict = {
  allowed: boolean;
  reason?: string;
};

/**
 * Pure evaluation function. Given a session's current ruleset and the active
 * foreground app/domain reported by the student client, return a verdict.
 *
 * This function is deliberately side-effect free and runs on both the server
 * (for audit) and the client (for instant blocking) so that students never
 * have to wait on a network round-trip to be blocked.
 */
export function evaluate(
  session: Pick<
    Session,
    "mode" | "status" | "blockedApps" | "blockedDomains" | "allowedApps" | "allowedDomains" | "autoUnlockAt"
  >,
  input: { app?: string | null; domain?: string | null },
): Verdict {
  // Session ended -> nothing is restricted.
  if (session.status !== "active") return { allowed: true };
  if (session.autoUnlockAt && new Date(session.autoUnlockAt).getTime() < Date.now()) {
    return { allowed: true };
  }

  const mode = session.mode as FocusMode;
  if (mode === "open") return { allowed: true };

  const app = (input.app || "").toLowerCase();
  const domain = (input.domain || "").toLowerCase();

  const blockedApps = (session.blockedApps as string[]) ?? [];
  const blockedDomains = (session.blockedDomains as string[]) ?? [];
  const allowedApps = (session.allowedApps as string[]) ?? [];
  const allowedDomains = (session.allowedDomains as string[]) ?? [];

  const matches = (needle: string, list: string[]) =>
    list.some((entry) => {
      const e = entry.trim().toLowerCase();
      if (!e) return false;
      return needle === e || needle.endsWith(`.${e}`) || needle.includes(e);
    });

  if (mode === "quiz") {
    // Whitelist mode – only explicitly allowed items pass.
    if (app && matches(app, allowedApps)) return { allowed: true };
    if (domain && matches(domain, allowedDomains)) return { allowed: true };
    return {
      allowed: false,
      reason: `Only the testing app is permitted during this quiz.`,
    };
  }

  // custom (blacklist) mode
  if (app && matches(app, blockedApps)) {
    return { allowed: false, reason: `“${input.app}” is restricted during class.` };
  }
  if (domain && matches(domain, blockedDomains)) {
    return { allowed: false, reason: `“${input.domain}” is restricted during class.` };
  }
  return { allowed: true };
}
