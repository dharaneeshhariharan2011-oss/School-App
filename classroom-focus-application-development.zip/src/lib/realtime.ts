/**
 * In-process pub/sub hub used to fan out SSE events to connected clients.
 *
 * We expose two independent channels per classroom session:
 *   - "teacher": receives student status changes + roster updates
 *   - "student:<token>": receives mode / ruleset changes
 *
 * In production this would be backed by Redis Pub/Sub so it can scale across
 * multiple Node processes, but for a single-process deployment this works
 * identically to Socket.io rooms.
 */

type Subscriber = (payload: string) => void;

type Hub = {
  channels: Map<string, Set<Subscriber>>;
};

const globalForHub = globalThis as typeof globalThis & {
  __classroomFocusHub?: Hub;
};

export const hub: Hub =
  globalForHub.__classroomFocusHub ??
  (globalForHub.__classroomFocusHub = { channels: new Map() });

export function subscribe(channel: string, cb: Subscriber): () => void {
  let subs = hub.channels.get(channel);
  if (!subs) {
    subs = new Set();
    hub.channels.set(channel, subs);
  }
  subs.add(cb);
  return () => {
    subs?.delete(cb);
    if (subs && subs.size === 0) hub.channels.delete(channel);
  };
}

export function publish(channel: string, event: string, data: unknown) {
  const subs = hub.channels.get(channel);
  if (!subs || subs.size === 0) return;
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const cb of subs) {
    try {
      cb(payload);
    } catch {
      // best-effort; connection may already be closed
    }
  }
}

/**
 * Helper to publish a status change to both the teacher dashboard and the
 * specific student (so the student can clear its intervention screen).
 */
export function publishToSession(sessionId: number, event: string, data: unknown) {
  publish(`session:${sessionId}:teacher`, event, data);
}

export function publishToStudent(token: string, event: string, data: unknown) {
  publish(`student:${token}`, event, data);
}
